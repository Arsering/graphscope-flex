import os

filename1='append_only_query_latency.json'
filename2='online_grouping_query_latency.json'

root_dir='/data-1/yichengzhang/data/latest_gs_bp/zed-graphscope-flex/experiment_space/LDBC_SNB/python/result/compare_result'

file1=os.path.join(root_dir, filename1)
file2=os.path.join(root_dir, filename2)

import json
import matplotlib.pyplot as plt
import os

# 创建保存结果的目录
output_dir = '/data-1/yichengzhang/data/latest_gs_bp/zed-graphscope-flex/experiment_space/LDBC_SNB/python/result/compare_result'
os.makedirs(output_dir, exist_ok=True)

# 读取两个json文件
with open(file1, 'r') as f:
    data1 = json.load(f)
with open(file2, 'r') as f:
    data2 = json.load(f)

# 获取并排序keys
keys1 = sorted([int(k) for k in data1.keys()])
keys2 = sorted([int(k) for k in data2.keys()])
# 准备数据
metrics = ['mean', 'p50', 'p99']

for key in keys1:
    for metric in metrics:
        # 为每个metric创建对应的文件夹
        metric_dir = os.path.join(output_dir, metric)
        os.makedirs(metric_dir, exist_ok=True)
        
        plt.figure(figsize=(10, 6))
        plt.plot(data1[str(key)][metric], label=f'append only')
        plt.plot(data2[str(key)][metric], label=f'online grouping')
        plt.title(f'Query {key} - {metric}')
        plt.xlabel('Time')
        plt.ylabel('Latency (ms)')
        plt.legend()
        plt.grid(True)
        plt.ylim(bottom=0)  # 设置y轴从0开始
        plt.savefig(os.path.join(metric_dir, f'query_{key}_{metric}.png'))
        plt.close()


